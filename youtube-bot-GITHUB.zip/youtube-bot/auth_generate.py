import telebot
from flask import Flask, request
import threading, json, os, time, uuid
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build

BOT_TOKEN = "8302278321:AAECyuSLmX2HYHwhxrLVnC-iE0lpcNmzcjU"
REDIRECT_URI = "https://3a5479f7626d.ngrok-free.app"
SCOPES = ["https://www.googleapis.com/auth/youtube.force-ssl", "https://www.googleapis.com/auth/userinfo.email", "openid"]

bot = telebot.TeleBot(BOT_TOKEN)
app = Flask(__name__)
users_state = {}

if not os.path.exists("tokens"):
    os.makedirs("tokens")

@bot.message_handler(commands=["start"])
def start(message):
    user_id = str(message.chat.id)
    state = str(uuid.uuid4())

    flow = Flow.from_client_secrets_file(
        "client_secret.json",
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI
    )

    auth_url, _ = flow.authorization_url(
        prompt="consent",
        access_type="offline",
        include_granted_scopes="true",
        state=state
    )

    users_state[state] = user_id
    bot.send_message(message.chat.id, f"🔐 Click below to login with Google:\n{auth_url}")

@app.route("/oauth2callback")
def oauth2callback():
    state = request.args.get("state")
    code = request.args.get("code")

    if state not in users_state:
        return "❌ Invalid or expired login session."

    user_id = users_state[state]

    try:
        flow = Flow.from_client_secrets_file(
            "client_secret.json",
            scopes=SCOPES,
            redirect_uri=REDIRECT_URI
        )
        flow.fetch_token(code=code)
        credentials = flow.credentials

        # 🔍 Get Gmail address from credentials
        youtube = build('oauth2', 'v2', credentials=credentials)
        user_info = youtube.userinfo().get().execute()
        email = user_info.get("email", "Unknown")

        # 🧾 Save token
        timestamp = int(time.time())
        token_filename = f"tokens/{user_id}_{timestamp}.json"
        token_data = {
            "email": email,
            "token": credentials.token,
            "refresh_token": credentials.refresh_token,
            "token_uri": credentials.token_uri,
            "client_id": credentials.client_id,
            "client_secret": credentials.client_secret,
            "scopes": credentials.scopes
        }

        with open(token_filename, "w") as f:
            json.dump(token_data, f)

        bot.send_message(int(user_id), f"✅ Login successful!\n📧 Logged in as: `{email}`\n💾 Token saved as: `{os.path.basename(token_filename)}`")

        del users_state[state]
        return "✅ You have successfully authorized! You can close this page."

    except Exception as e:
        return f"❌ Error during authorization: {str(e)}"

def run_flask():
    app.run(host="0.0.0.0", port=8080)

if __name__ == "__main__":
    threading.Thread(target=run_flask, daemon=True).start()
    bot.polling()