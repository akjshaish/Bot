import os
import json
import re
import telebot
from google.oauth2.credentials import Credentials
import google.auth.transport.requests
from googleapiclient.discovery import build

BOT_TOKEN = "8302278321:AAECyuSLmX2HYHwhxrLVnC-iE0lpcNmzcjU"
bot = telebot.TeleBot(BOT_TOKEN)

# ✅ Get all YouTube service objects from tokens folder
def load_youtube_services():
    services = []
    folder_path = "tokens"
    for filename in sorted(os.listdir(folder_path)):
        if filename.endswith(".json"):
            with open(os.path.join(folder_path, filename), "r") as f:
                data = json.load(f)
            creds = Credentials(
                token=data["token"],
                refresh_token=data["refresh_token"],
                token_uri=data["token_uri"],
                client_id=data["client_id"],
                client_secret=data["client_secret"],
                scopes=data["scopes"]
            )
            if not creds.valid and creds.expired and creds.refresh_token:
                creds.refresh(google.auth.transport.requests.Request())
            service = build("youtube", "v3", credentials=creds)
            services.append(service)
    return services


# 🎯 Extract ID from link or raw
def extract_video_id(link):
    match = re.search(r"(?:v=|\/videos\/|youtu\.be\/|\/embed\/)([a-zA-Z0-9_-]{11})", link)
    return match.group(1) if match else link.strip()

def extract_channel_id(link):
    match = re.search(r"(?:channel\/|\/c\/|\/@)?([a-zA-Z0-9_-]{24})", link)
    return f"UC{match.group(1)[-22:]}" if match else link.strip()


@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, "👋 Welcome! Use:\n/like 5 [video]\n/subscribe 3 [channel]\n/comment 2 [video] | message")


@bot.message_handler(commands=['like'])
def like_video(msg):
    try:
        parts = msg.text.split()
        count = int(parts[1])
        video_id = extract_video_id(parts[2])
        services = load_youtube_services()
        
        success = 0
        errors = []

        for i, yt in enumerate(services[:count]):
            try:
                yt.videos().rate(rating="like", id=video_id).execute()
                success += 1
            except Exception as e:
                errors.append(f"{i+1}: {os.listdir('tokens')[i]} → {str(e).split(':')[0]}")

        reply = f"👍 Liked from {success} account(s).\n"
        if errors:
            reply += f"\n❌ Errors:\n" + "\n".join(errors)
        bot.reply_to(msg, reply)
    except Exception as e:
        bot.reply_to(msg, f"❌ Error: {e}")


@bot.message_handler(commands=['subscribe'])
def sub_channel(msg):
    try:
        parts = msg.text.split()
        count = int(parts[1])
        channel_id = extract_channel_id(parts[2])
        services = load_youtube_services()

        success = 0
        errors = []

        for i, yt in enumerate(services[:count]):
            try:
                yt.subscriptions().insert(
                    part="snippet",
                    body={
                        "snippet": {
                            "resourceId": {
                                "kind": "youtube#channel",
                                "channelId": channel_id
                            }
                        }
                    }
                ).execute()
                success += 1
            except Exception as e:
                errors.append(f"{i+1}: {os.listdir('tokens')[i]} → {str(e).split(':')[0]}")

        reply = f"📌 Subscribed from {success} account(s).\n"
        if errors:
            reply += f"\n❌ Errors:\n" + "\n".join(errors)
        bot.reply_to(msg, reply)
    except Exception as e:
        bot.reply_to(msg, f"❌ Error: {e}")


@bot.message_handler(commands=['comment'])
def comment_video(msg):
    try:
        split = msg.text.split(" ", 2)
        count = int(split[1])
        video_part = split[2]
        video_id, comment_text = video_part.split("|", 1)
        video_id = extract_video_id(video_id.strip())
        comment_text = comment_text.strip()

        services = load_youtube_services()
        success = 0
        errors = []

        for i, yt in enumerate(services[:count]):
            try:
                yt.commentThreads().insert(
                    part="snippet",
                    body={
                        "snippet": {
                            "videoId": video_id,
                            "topLevelComment": {
                                "snippet": {
                                    "textOriginal": comment_text
                                }
                            }
                        }
                    }
                ).execute()
                success += 1
            except Exception as e:
                errors.append(f"{i+1}: {os.listdir('tokens')[i]} → {str(e).split(':')[0]}")

        reply = f"💬 Commented from {success} account(s).\n"
        if errors:
            reply += f"\n❌ Errors:\n" + "\n".join(errors)
        bot.reply_to(msg, reply)
    except Exception as e:
        bot.reply_to(msg, f"❌ Error: {e}")


print("🤖 Bot running...")
bot.polling()